from Chuong3_OOP.Baitap61.models.QuanLy import QuanLy
from Chuong3_OOP.Baitap61.models.Address import Address
from Chuong3_OOP.Baitap61.models.Student import Student

def main():
    Quanly=QuanLy()
    while True:
        print("*" * 45)
        print("======Menu======")
        print("1. Add Student")
        print("2. Update Student")
        print("3. Remove Student")
        print("4. Show All Students")
        print("5. Filter Students by City")
        print("6. Exit")
        print("*" * 45)
        choice = input("Enter your choice: ")


        if choice == "1":
            print("*" * 45)
            first_name= input("Enter first name:")
            last_name=input("Enter last name:")
            print("*"*45)
            print("Enter Home address:")
            home_street= input("Enter Home street:")
            home_city=input("Enter Home city:")
            home_state=input("Enter Home state:")
            home_zipCode=input("Enter Home Zipcode:")
            homeAddress=Address(home_street,home_city,home_state,home_zipCode)
            print("*" * 45)
            print("Enter School address")
            school_street = input("Enter School street:")
            school_city = input("Enter School city:")
            school_state = input("Enter School state:")
            school_zipCode = input("Enter School Zipcode:")
            print("*" * 45)
            schoolAddress = Address(school_street, school_city, school_state, school_zipCode)

            student=Student(first_name, last_name, homeAddress, schoolAddress)
            Quanly.add_student(student)

        elif choice == "2":
            print("*" * 45)
            index = int(input("Enter student index to update:")) - 1
            first_name = input("Enter new first name:")
            last_name = input("Enter new last name:")
            print("*" * 45)
            print("Enter new Home address:")
            home_street = input("Enter new Home street:")
            home_city = input("Enter new Home city:")
            home_state = input("Enter new Home state:")
            home_zipCode = input("Enter new Home Zipcode:")
            homeAddress = Address(home_street, home_city, home_state, home_zipCode)
            print("*" * 45)
            print("Enter new School address")
            school_street = input("Enter new School street:")
            school_city = input("Enter new School city:")
            school_state = input("Enter new School state:")
            school_zipCode = input("Enter new School Zipcode:")
            print("*" * 45)
            schoolAddress = Address(school_street, school_city, school_state, school_zipCode)

            student = Student(first_name, last_name, homeAddress, schoolAddress)
            Quanly.update_student(index,student)

        elif choice == "3":
            index = int(input("Enter student index to remove:")) - 1
            Quanly.remove_student(index)

        elif choice == "4":
            Quanly.showAll()

        elif choice == "5":
            city = input("Enter city to filter students:")
            print("Students in city:")
            Quanly.filter_student_with_city(city)

        elif choice == "6":
            print("Bye bye!!")
            break

        else:
            print("Invalid choice. Try again")

if __name__ == "__main__":
    main()