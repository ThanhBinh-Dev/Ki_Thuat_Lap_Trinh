class Student:
    def __init__(self, firstName, lastName, homeAddress, schoolAddress):
        self.firstName = firstName
        self.lastName = lastName
        self.homeAddress = homeAddress
        self.schoolAddress = schoolAddress
    def __str__(self):
        return (f"Name: {self.firstName} {self.lastName}"
                f"Home Address: {self.homeAddress}"
                f"School Address: {self.schoolAddress}")
