from Chuong3_OOP.Baitap61.models.Student import Student
from Chuong3_OOP.Baitap61.models.Address import Address

class QuanLy:
    def __init__(self):
        self.students = []

    def showAll(self):
        for i, student in enumerate(self.students, start=1):
            print(f"Sinh viên {i}: {student}")

    def add_student(self, student):
        self.students.append(student)

    def update_student(self, index, student):
        if 0<= index <=len(self.students):
            self.students[index] = student
        else:
            print("Index khong ton tai!!")

    def remove_student(self,index):
        if 0<= index <=len(self.students):
            self.students.pop(index)
        else:
            print("Index khong ton tai!!")

    def filter_student_with_city(self, city):
        filter_students = [s for s in self.students if s.homeAddress.city == city or s.schoolAddress.city == city]
        for student in filter_students:
            print(student)
