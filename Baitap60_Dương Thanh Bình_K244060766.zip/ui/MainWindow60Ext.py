import functools

from PyQt6.QtCore import QDate
from PyQt6.QtWidgets import QPushButton, QMessageBox

from Chuong3_OOP.Baitap60.ui.MainWindow import Ui_MainWindow


class MainWindow60Ext(Ui_MainWindow):
    def __init__(self):
        self.students = []
        self.previous_button = None
        self.selected_index = -1

    def setupUi(self, MainWindow):
        super().setupUi(MainWindow)
        self.MainWindow = MainWindow
        self.setupSignalAndSlot()

    def showWindow(self):
        self.MainWindow.show()

    def setupSignalAndSlot(self):
        self.pushButtonSave.clicked.connect(self.xuly_luu_sinhvien)
        self.pushButtonRemove.clicked.connect(self.xuly_xoa_sinhvien)
        self.pushButtonFilterName.clicked.connect(self.xuly_tim_theo_ten)
        self.pushButtonFilterMonth.clicked.connect(self.xuly_loc_theo_thang_sinh)
        self.pushButtonClear.clicked.connect(self.xuly_xoa_input)
        self.pushButtonShowAll.clicked.connect(self.xuly_hienthi_tatca)

    def clearLayout(self, layout):
        if layout is not None:
            while layout.count():
                item = layout.takeAt(0)
                widget = item.widget()
                if widget is not None:
                    widget.deleteLater()
                else:
                    self.clearLayout(item.layout())

    def doimau_nen(self, i):
        sender = self.MainWindow.sender()
        if self.previous_button is not None:
            self.previous_button.setStyleSheet("background-color: rgb(240,237,237);")
        sender.setStyleSheet("background-color: rgb(170,255,255);")
        self.previous_button = sender
        self.selected_index = i

    def xuly_luu_sinhvien(self):
        student = {
            "mssv": self.lineEditMSSV.text(),
            "ho_ten": self.lineEditHoVaTen.text(),
            "ngay_sinh": self.lineEditDateTime.text(),
        }
        self.students.append(student)
        self.hienthi_sinhvien_len_giaodien()

    def hienthi_sinhvien_len_giaodien(self):
        self.clearLayout(self.verticalLayoutSinhVien)
        for i in range(len(self.students)):
            student = self.students[i]
            student_button = QPushButton(text=student["ho_ten"])
            student_button.setStyleSheet("background-color: rgb(240,237,237);")
            self.verticalLayoutSinhVien.addWidget(student_button)
            student_button.clicked.connect(functools.partial(self.xem_chitiet, i))
            student_button.clicked.connect(functools.partial(self.doimau_nen, i))

    def xem_chitiet(self, i):
        student = self.students[i]
        self.lineEditMSSV.setText(student["mssv"])
        self.lineEditHoVaTen.setText(student["ho_ten"])
        self.lineEditDateTime.setText(student["ngay_sinh"])

    def xuly_xoa_sinhvien(self):
        if self.selected_index == -1:
            QMessageBox.warning(self.MainWindow, "Lỗi", "Chưa chọn sinh viên nào!")
            return

        try:
            self.students.pop(self.selected_index)
        except IndexError:
            return

        self.selected_index = -1
        self.previous_button = None
        self.xuly_xoa_input()
        self.hienthi_sinhvien_len_giaodien()

    def xuly_xoa_input(self):
        self.lineEditMSSV.clear()
        self.lineEditHoVaTen.clear()
        self.lineEditDateTime.clear()

    def xuly_tim_theo_ten(self):
        search_name = self.lineEditHoVaTen.text().strip().lower()
        filtered_students = [sv for sv in self.students if search_name in sv["ho_ten"].lower()]
        self.display_filtered_students(filtered_students)

    def xuly_loc_theo_thang_sinh(self):
        try:
            current_month = QDate.currentDate().month()
            filtered_students = [
                sv
                for sv in self.students
                if QDate.fromString(sv["ngay_sinh"], "dd/MM/yyyy").month() == current_month
            ]
            self.display_filtered_students(filtered_students)
        except Exception:
            QMessageBox.warning(self.MainWindow, "Lỗi", "Ngày sinh không hợp lệ!")

    def display_filtered_students(self, students):
        if not students:
            QMessageBox.information(self.MainWindow, "Thông báo", "Không tìm thấy sinh viên nào phù hợp!")
            return

        self.clearLayout(self.verticalLayoutSinhVien)
        for student in students:
            student_button = QPushButton(text=student["ho_ten"])
            student_button.setStyleSheet("background-color: rgb(240,237,237);")
            self.verticalLayoutSinhVien.addWidget(student_button)

    def xuly_hienthi_tatca(self):
        self.hienthi_sinhvien_len_giaodien()

