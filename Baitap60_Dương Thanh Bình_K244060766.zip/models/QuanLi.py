class QuanLyDanhSach:
    def __init__(self):
        self.danh_sach = []
    def them_sinh_vien(self, sinh_vien):
        self.danh_sach.append(sinh_vien)
    def tong_so_sinh_vien(self):
        return len(self.danh_sach)
    def tim_theo_ho_ten(self, ho_ten):
        return [sv for sv in self.danh_sach if sv.ho_ten == ho_ten]
    def tim_theo_thang_sinh(self, thang):
        return [sv for sv in self.danh_sach if sv.ngay_sinh.month == thang]
    def sap_xep_theo_tuoi(self):
        self.danh_sach.sort(key=lambda sv: sv.tuoi)