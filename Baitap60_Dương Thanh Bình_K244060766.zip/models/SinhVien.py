from datetime import datetime

class Student:
    def __init__(self, ma_sv, ho_ten, ngay_sinh):
        self.ma_sv = ma_sv
        self.ho_ten = ho_ten
        self.ngay_sinh = datetime.strptime(ngay_sinh, "%d/%m/%Y")
    @property
    def ho(self):
        return self.ho_ten.split(" ", 1)[0]  # Lấy họ từ họ và tên
    @property
    def ten(self):
        return self.ho_ten.split(" ", 1)[-1]  # Lấy tên từ họ và tên
    @property
    def tuoi(self):
        today = datetime.today()
        return today.year - self.ngay_sinh.year - (
            (today.month, today.day) < (self.ngay_sinh.month, self.ngay_sinh.day)
        )
    def in_thong_tin(self):
        return f"MSSV: {self.ma_sv}, Họ và tên: {self.ho_ten}, Ngày sinh: {self.ngay_sinh.strftime('%d/%m/%Y')}, Tuổi: {self.tuoi}"
