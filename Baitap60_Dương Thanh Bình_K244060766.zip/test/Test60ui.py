from PyQt6.QtWidgets import QApplication, QMainWindow

from Chuong3_OOP.Baitap60.ui.MainWindow60Ext import MainWindow60Ext

app=QApplication([])
mainwindow=QMainWindow()
myui=MainWindow60Ext()
myui.setupUi(mainwindow)
myui.showWindow()
app.exec()