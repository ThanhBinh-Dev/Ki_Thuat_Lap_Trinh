from Chuong3_OOP.Baitap60.models.QuanLi import QuanLyDanhSach
from Chuong3_OOP.Baitap60.models.SinhVien import Student
from datetime import datetime

def main():
    # Tạo danh sách quản lý
    qlds = QuanLyDanhSach()

    # Nhập sinh viên
    print("Nhập thông tin sinh viên:")
    for i in range(2):  # Thêm 2 sinh viên
        ma_sv = input(f"Nhập mã số sinh viên {i+1}: ")
        ho_ten = input("Nhập họ và tên: ")
        ngay_sinh = input("Nhập ngày sinh (dd/mm/yyyy): ")
        sv = Student(ma_sv, ho_ten, ngay_sinh)
        qlds.them_sinh_vien(sv)

    # Hiển thị thông tin sinh viên
    print("\nDanh sách sinh viên:")
    for sv in qlds.danh_sach:
        print(sv.in_thong_tin())

    # Tìm sinh viên theo tên
    ho_ten_tim = input("\nNhập họ tên để tìm kiếm: ")
    ket_qua = qlds.tim_theo_ho_ten(ho_ten_tim)
    if ket_qua:
        print("Kết quả tìm kiếm:")
        for sv in ket_qua:
            print(sv.in_thong_tin())
    else:
        print("Không tìm thấy sinh viên.")

    # Tìm sinh viên có ngày sinh trong tháng hiện tại
    thang_hien_tai = datetime.today().month
    ket_qua = qlds.tim_theo_thang_sinh(thang_hien_tai)
    print(f"\nSinh viên sinh trong tháng {thang_hien_tai}:")
    if ket_qua:
        for sv in ket_qua:
            print(sv.in_thong_tin())
    else:
        print("Không có sinh viên nào.")

    # Sắp xếp sinh viên theo tuổi
    qlds.sap_xep_theo_tuoi()
    print("\nDanh sách sinh viên sau khi sắp xếp theo tuổi:")
    for sv in qlds.danh_sach:
        print(sv.in_thong_tin())

if __name__ == "__main__":
    main()